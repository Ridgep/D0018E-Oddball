<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<a href="http://utbweb.its.ltu.se/~ridpet-5/Index.php"><h1>Oddball</h1></a>


  <ps>
    <a href="http://utbweb.its.ltu.se/~ridpet-5/Product.php">Product</a>
    <a href="http://utbweb.its.ltu.se/~ridpet-5/Cart.php">Cart</a>
    <a href="http://utbweb.its.ltu.se/~ridpet-5/Login.php">Login</a>
    <a href="http://utbweb.its.ltu.se/~ridpet-5/Logout.php">Logout</a>
    <a href="http://utbweb.its.ltu.se/~ridpet-5/Support.php">Support</a>
  </ps>

</body>
</html>
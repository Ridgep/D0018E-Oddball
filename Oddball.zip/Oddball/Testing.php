<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<body>
<h1>Welcome to my home page!</h1>
<p>Some text.</p>
<p>Some more text.</p>
<?php include 'Index.php';?>

</body>
</html>
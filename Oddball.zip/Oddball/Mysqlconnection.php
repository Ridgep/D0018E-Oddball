<?php
$servername = "utbweb.its.ltu.se";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = mysqli_connect($servername, $username, $password);
// Check connection
if (!$conn){
    die("Connection failed: " . mysqli_connect_error());
}
?>
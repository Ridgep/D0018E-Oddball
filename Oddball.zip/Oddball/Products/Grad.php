<!DOCTYPE html>
<html>
<?php
  require ("../Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="../Stylesheet.css">
</head>
<body>

<?php include '../Menu.php';?>


<p>
  <div class="dropdown">
    <span>Special products</span>
    <div class="dropdown-content">
      <form action="http://utbweb.its.ltu.se/~ridpet-5/Products/Grad.php" method="post">
        <input type="submit" value="Graduation"/>
      </form>
      <form action="http://utbweb.its.ltu.se/~ridpet-5/Products/Soul.php" method="post">
        <input type="submit" value="Soul"/>
      </form>
      <form action="http://utbweb.its.ltu.se/~ridpet-5/Products/Life.php" method="post">
        <input type="submit" value="Life"/>
      </form>
    </div>
  </div>
</p>

<p>Product: Graduation<br>
   Price: <?php echo file_get_contents("life_prod.txt"); ?><br>
   Number in storage: 69
</p>

<form action="/prod_buy.php">
  <div class="container">
    <p>
    <label><b>Amount</b></label>
    <input type="text" placeholder="Enter Amount" name="amount" required>
    <button type="submit">Buy</button>
    </p>
</form>

<?php include '../Copyright.php';?>

</body>
</html>
<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php include 'Menu.php';?>
<?php include 'Copyright.php';?>

</body>
</html>
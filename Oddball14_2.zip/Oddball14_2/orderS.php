<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php 

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

include 'Menu.php';

  if(isset($_SESSION['logged']) && $_SESSION['logged']){
  $orderId = $_SESSION['orderId'];
  $id = $_SESSION['id'];
  
  $sql = "SELECT idOrders, Total FROM Orders WHERE ShoppingCart_User_idUser = '$orderId' && User_idUser = '$id'";
  
  $total = $conn->query($sql)->fetch_assoc();
  
  $ordernum = ($orderId*10)+$total['idOrders'];
  
  echo "Your order " . $ordernum . " has been recieved.<br>
  It will be sent as soon as you pay a total sum of " . $total['Total'] . ".<br>";
  }

include 'Copyright.php';?>

</body>
</html>
<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php include 'Menu.php';?>

<form action="Actions/Log_in.php" target="_self" method="POST">

  <div class="container">
    <p>
    <label><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>
    </p>

    <p>
    <label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
    </p>

    <button type="submit">Login</button>

  </div>
</form>
</p>

<?php include 'Copyright.php';?>

</body>
</html>
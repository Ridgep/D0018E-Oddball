<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<pc>&copy; 2017 Oddball<pc>

</body>
</html>
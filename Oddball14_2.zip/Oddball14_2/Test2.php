<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<body>
<h1>Test number 2</h1>
<p>Text text text.</p>
<?php include 'Index.php';?>
<?php include 'Copyright.php';?>
</body>
</html>
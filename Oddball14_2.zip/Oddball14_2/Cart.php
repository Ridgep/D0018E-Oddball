<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php include 'Menu.php';

  if(isset($_SESSION['logged']) && $_SESSION['logged']){
    echo "Life in your cart " . $_SESSION['lCart_quant'] . ".<br>
    Souls in your cart " . $_SESSION['sCart_quant'] . ".<br>
    Graduations in your cart " . $_SESSION['gCart_quant'] .".
    
    <form action='Actions/orderA.php' target='_self' method='POST'>
      <div class='container'>
	<p>
	<button type='submit'>Order</button>
	</p>
    </form>";
  }
  else{ echo "<p><b> You need to be logged in to see your cart! </p></b>"; }

include 'Copyright.php';?>

</body>
</html>
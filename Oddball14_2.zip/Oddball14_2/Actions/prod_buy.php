<?php session_start(); ?>
<!DOCTYPE html>
<html>
<?php
  require ("../Mysqlconnection.php");
?>
<body>

<?php

$_SESSION['Amount'] = $_POST['amount'];

header('Location: http://utbweb.its.ltu.se/~ridpet-5/Cart.php');
?>

</body>
</html>
<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

session_start();

if(isset($_SESSION['logged']) && $_SESSION['logged']){
  $sql = "SELECT Cost, Stock FROM Products WHERE Prodname = 'Life'";
  $life = $conn->query($sql)->fetch_assoc();
  $ldiff = $life['Stock'] - $_SESSION['lCart_quant'];
  
  $sql = "SELECT Cost, Stock FROM Products WHERE Prodname = 'Soul'";
  $soul = $conn->query($sql)->fetch_assoc();
  $sdiff = $soul['Stock'] - $_SESSION['sCart_quant'];
  
  $sql = "SELECT Cost, Stock FROM Products WHERE Prodname = 'Graduation'";
  $grad = $conn->query($sql)->fetch_assoc();
  $gdiff = $grad['Stock'] - $_SESSION['gCart_quant'];
  
  if($_SESSION['lCart_quant'] == 0 && $_SESSION['sCart_quant'] == 0 && $_SESSION['gCart_quant'] == 0){
    header('Location: ../orderF.php');
    }
  
  elseif(($life['Stock'] > 0 && $ldiff >= 0) && ($soul['Stock'] > 0 && $sdiff >= 0) && ($grad['Stock'] > 0 && $gdiff >= 0)){
    $sql = "UPDATE Products SET Stock = $ldiff WHERE Prodname = 'Life'";
    $conn->query($sql);
    
    $sql = "UPDATE Products SET Stock = $sdiff WHERE Prodname = 'Soul'";
    $conn->query($sql);
    
    $sql = "UPDATE Products SET Stock = $gdiff WHERE Prodname = 'Graduation'";
    $conn->query($sql);
    
    $id = $_SESSION['id'];
    $lid = $_SESSION['lCart_prodId'];
    $sid = $_SESSION['sCart_prodId'];
    $gid = $_SESSION['gCart_prodId'];
    
    $sql = "UPDATE ShoppingCart SET Quantity = 0 WHERE User_idUser = '$id' && Products_idProducts = '$lid'";
    $conn->query($sql);
    
    $sql = "UPDATE ShoppingCart SET Quantity = 0 WHERE User_idUser = '$id' && Products_idProducts = '$sid'";
    $conn->query($sql);
    
    $sql = "UPDATE ShoppingCart SET Quantity = 0 WHERE User_idUser = '$id' && Products_idProducts = '$gid'";
    $conn->query($sql);
    
    $total = ($_SESSION['lCart_quant'] * $life['Cost']) + ($_SESSION['sCart_quant'] * $soul['Cost']) + ($_SESSION['gCart_quant'] * $grad['Cost']);
    
    $orderId = $_SESSION['lCart_quant'];
    $orderId = ($orderId*10) + $_SESSION['sCart_quant'];
    $orderId = ($orderId*10) + $_SESSION['gCart_quant'];
    
    $sql = "INSERT INTO Orders (ShoppingCart_User_idUser, Total, User_idUser)
    VALUES ('$orderId', '$total', '$id')";
    
    $_SESSION['orderId'] = $orderId;
    
    $conn->query($sql);
    
    $_SESSION['lCart_quant'] = 0;
    $_SESSION['sCart_quant'] = 0;
    $_SESSION['gCart_quant'] = 0;
    
    header('Location: ../orderS.php');
    
    }
  else{ header('Location: ../orderF.php'); }

  }

?>
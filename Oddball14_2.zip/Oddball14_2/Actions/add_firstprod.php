<?php 

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}
 
$prodname = "Life";
$desc = "Its the life you wish you had!";
$cost = "9000";
$stock = 4;

$sql = "INSERT INTO Products (Prodname, Description, Cost, Stock)
VALUES ('$prodname', '$desc', '$cost', '$stock')";

if($conn->query($sql)){
  echo "1 success!";
}
else{
  echo "fail";
}

$prodname = "Soul";
$desc = "Soul for your ginger friend!";
$cost = "69";
$stock = 2;

$sql = "INSERT INTO Products (Prodname, Description, Cost, Stock)
VALUES ('$prodname', '$desc', '$cost', '$stock')";

if($conn->query($sql)){
  echo "2 success!";
}
else{
  echo "fail";
}

$prodname = "Graduation";
$desc = "What we strive to get from university.";
$cost = "10000";
$stock = 67;

$sql = "INSERT INTO Products (Prodname, Description, Cost, Stock)
VALUES ('$prodname', '$desc', '$cost', '$stock')";

if($conn->query($sql)){
  echo "3 success!";
}
else{
  echo "fail";
}
?>
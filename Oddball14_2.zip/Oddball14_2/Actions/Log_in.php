<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

$uname = $_POST['uname'];
$pass = $_POST['psw'];

$sql = "SELECT Username, Password, idUser, Admin FROM User WHERE Username = '$uname'";

$check = $conn->query($sql)->fetch_assoc();

 


if ($check['Username'] == $uname && $check['Password'] == $pass){
	session_start();
	if(isset($check['Admin']) && $check['Admin']){
	    $_SESSION['admin'] = $check['Admin'];
	}
	$_SESSION['user'] = $check['Username'];
	$_SESSION['id'] = $check['idUser'];
	$id = $_SESSION['id'];
	$_SESSION['logged'] = True;
	
	$sql = "SELECT Products_idProducts, Quantity FROM ShoppingCart WHERE User_idUser = '$id'";
	$res = $conn->query($sql);
	
	$cart = $res->fetch_assoc();
	$_SESSION['lCart_prodId'] = $cart['Products_idProducts'];
	$_SESSION['lCart_quant'] = $cart['Quantity'];
	echo $_SESSION['lCart_prodId'];
	echo $_SESSION['lCart_quant']."<br>";
	
	$cart = $res->fetch_assoc();
	$_SESSION['sCart_prodId'] = $cart['Products_idProducts'];
	$_SESSION['sCart_quant'] = $cart['Quantity'];
	echo $_SESSION['sCart_prodId'];
	echo $_SESSION['sCart_quant']."<br>";
	
	$cart = $res->fetch_assoc();
	$_SESSION['gCart_prodId'] = $cart['Products_idProducts'];
	$_SESSION['gCart_quant'] = $cart['Quantity'];
	echo $_SESSION['gCart_prodId'];
	echo $_SESSION['gCart_quant']."<br>";
	header('Location: ../Cart.php');
}
else{ echo "Password or Username was wrongly entered.";}
?>
<!DOCTYPE html>
<html>
<body>
<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

$uname = 'admin';
$pass = 'admin';
$admin = True;

$sql = 'SELECT Username FROM User';

$check = $conn->query($sql);

$sql = "INSERT INTO User (Username, Password, Admin)
VALUES ('$uname', '$pass', '$admin')";

$found=0;

if ($check->num_rows > 0){
	while($checki = $check->fetch_assoc()){
		if($uname == $checki['Username']){
			$found=1;
			
		}
	}
}
if($found == 0){
  $conn->query($sql);
  
  $quantity=0;
  
  $sql = "SELECT idUser FROM User WHERE Username = '$uname'";
  $userid = $conn->query($sql)->fetch_assoc();
  $userid = $userid['idUser'];
  
  $sql = "SELECT idProducts FROM Products WHERE Prodname = 'Life'";
  $prodid = $conn->query($sql)->fetch_assoc();
  $prodid = $prodid['idProducts'];
  
  $sql = "INSERT INTO ShoppingCart(User_idUser, Products_idProducts, Quantity)
  VALUES ('$userid', '$prodid', '$quantity')";
 
  $conn->query($sql);
  
  //
  
  $sql = "SELECT idProducts FROM Products WHERE Prodname = 'Soul'";
  $prodid = $conn->query($sql)->fetch_assoc();
  $prodid = $prodid['idProducts'];
  
  $sql = "INSERT INTO ShoppingCart(User_idUser, Products_idProducts, Quantity)
  VALUES ('$userid', '$prodid', '$quantity')";
  
  $conn->query($sql);
  
  //
  
  $sql = "SELECT idProducts FROM Products WHERE Prodname = 'Graduation'";
  $prodid = $conn->query($sql)->fetch_assoc();
  $prodid = $prodid['idProducts'];
  
  $sql = "INSERT INTO ShoppingCart(User_idUser, Products_idProducts, Quantity)
  VALUES ('$userid', '$prodid', '$quantity')";
  
  $conn->query($sql);
  
  header('Location: http://utbweb.its.ltu.se/~ridpet-5/Login.php');
}
else{
echo "Admin failed to create because it exists!";
}

$conn->close();

?>

</body>
</html>
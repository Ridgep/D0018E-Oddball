<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

session_start();

$id = $_SESSION['id'];
$lid = $_SESSION['lCart_prodId'];
$sid = $_SESSION['sCart_prodId'];
$gid = $_SESSION['gCart_prodId'];

$lquant = $_SESSION['lCart_quant'];
$squant = $_SESSION['sCart_quant'];
$gquant = $_SESSION['gCart_quant'];


$sql = "UPDATE ShoppingCart SET Quantity = $lquant WHERE User_idUser = '$id' && Products_idProducts = '$lid'";

$conn->query($sql);

$sql = "UPDATE ShoppingCart SET Quantity = $squant WHERE User_idUser = '$id' && Products_idProducts = '$sid'";

$conn->query($sql);

$sql = "UPDATE ShoppingCart SET Quantity = $gquant WHERE User_idUser = '$id' && Products_idProducts = '$gid'";

$conn->query($sql);

session_unset(); 
session_destroy();

header('Location: http://utbweb.its.ltu.se/~ridpet-5/index.php');
?>

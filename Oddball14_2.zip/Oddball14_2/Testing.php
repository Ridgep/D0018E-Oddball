echo "
	<a href='http://utbweb.its.ltu.se/~ridpet-5/admin_page.php'>Admin Page</a>";
if(isset($_SESSION['admin']) && $_SESSION['admin']){
echo "<form action='Actions/add_firstprod.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <button type='submit'>Add</button>
    </p>
</form>";
}
else{ echo "bugged".$_SESSION['admin'];}

$prod = $prods->fetch_assoc();
echo "Product: ".$prod['Prodname']."<br>
Current description: ".$prod['Description']."<br>
Current price: ".$prod['Cost']."<br>
Current stock: ".$prod['Stock']."<br><br>";

$prod = $prods->fetch_assoc();
echo "Product: ".$prod['Prodname']."<br>
Current description: ".$prod['Description']."<br>
Current price: ".$prod['Cost']."<br>
Current stock: ".$prod['Stock']."<br><br>";


<?php 

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

$newp = $_POST['newp'];

$sql = "UPDATE Products SET Cost = $newp WHERE idProducts = 8";

if($conn->query($sql)){
  echo "Success!";
}
else{ echo "fail"; }

$conn->close();
?>


if((isset($_SESSION['Lamount']) && $_SESSION['Lamount'] > 0) || (isset($_SESSION['Gamount']) && $_SESSION['Gamount'] > 0) || (isset($_SESSION['Samount']) && $_SESSION['Samount'] > 0)){
    if(!isset($_SESSION['Lamount'])){
    $_SESSION['Lamount'] = 0;
    }
    if(!isset($_SESSION['Samount'])){
    $_SESSION['Samount'] = 0;
    }
    if(!isset($_SESSION['Gamount'])){
    $_SESSION['Gamount'] = 0;
    }
    echo "Life in your cart " . $_SESSION['Lamount'] . ".<br>
    Souls in your cart " . $_SESSION['Samount'] . ".<br>
    Graduations in your cart " . $_SESSION['Gamount'].".";
    }
  else{
    echo "Cart is empty!";
    }
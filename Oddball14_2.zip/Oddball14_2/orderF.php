<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php include 'Menu.php';

  if(isset($_SESSION['logged']) && $_SESSION['logged']){
  echo "Your order could not be made, since there is a lacking amount of articles in storage to make your order. <br>
  Please wait until an admin has added more products for you to make your order!<br><br>";
  
  echo "<b>Or a rare occassion that you are a numbskull that makes an order without items in your cart!</b>";
  }
  
  include 'Copyright.php';?>

</body>
</html>
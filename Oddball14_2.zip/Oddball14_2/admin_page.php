<!DOCTYPE html>
<html>
<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php include 'Menu.php';

if(isset($_SESSION['admin']) && $_SESSION['admin']){

$sql = "SELECT Prodname, Description, Cost, Stock FROM Products WHERE Prodname = 'Life'";

$prod = $conn->query($sql)->fetch_assoc();

echo "Product: ".$prod['Prodname']."<br>
Current description: ".$prod['Description']."<br>
Current price: ".$prod['Cost']."<br>

<form action='Actions/editPriceL.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='New price' name='newp' required>
    <button type='submit'>Change</button>
    </p>
</form>

Current stock: ".$prod['Stock']."<br>

<form action='Actions/editStockL.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='Add stock' name='addst' required>
    <button type='submit'>Add</button>
    </p>
</form><br>";

$sql = "SELECT Prodname, Description, Cost, Stock FROM Products WHERE Prodname = 'Soul'";

$prod = $conn->query($sql)->fetch_assoc();

echo "Product: ".$prod['Prodname']."<br>
Current description: ".$prod['Description']."<br>
Current price: ".$prod['Cost']."<br>

<form action='Actions/editPriceS.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='New price' name='newp' required>
    <button type='submit'>Change</button>
    </p>
</form>

Current stock: ".$prod['Stock']."<br>

<form action='Actions/editStockS.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='Add stock' name='addst' required>
    <button type='submit'>Add</button>
    </p>
</form><br>";

$sql = "SELECT Prodname, Description, Cost, Stock FROM Products WHERE Prodname = 'Graduation'";

$prod = $conn->query($sql)->fetch_assoc();

echo "Product: ".$prod['Prodname']."<br>
Current description: ".$prod['Description']."<br>
Current price: ".$prod['Cost']."<br>

<form action='Actions/editPriceG.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='New price' name='newp' required>
    <button type='submit'>Change</button>
    </p>
</form>

Current stock: ".$prod['Stock']."<br>

<form action='Actions/editStockG.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='Add stock' name='addst' required>
    <button type='submit'>Add</button>
    </p>
</form><br>";

}

include 'Copyright.php'; ?>

</body>
</html>
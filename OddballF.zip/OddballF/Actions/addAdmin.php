<!DOCTYPE html>
<html>
<body>
<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

$uname = 'admin';
$pass = 'admin';
$admin = True;
$date = date('Y.m.d');

$sql = 'SELECT Username FROM User';

$check = $conn->query($sql);

$sql = "INSERT INTO User (Username, Password, Admin, Date)
VALUES ('$uname', '$pass', '$admin', '$date')";

$found=0;

if ($check->num_rows > 0){
	while($checki = $check->fetch_assoc()){
		if($uname == $checki['Username']){
			$found=1;
			
		}
	}
}
if($found == 0){
  $conn->query($sql);
  
  header('Location: http://utbweb.its.ltu.se/~ridpet-5/Login.php');
}
else{
echo "Admin failed to create because it exists!";
}

$conn->close();

?>

</body>
</html>
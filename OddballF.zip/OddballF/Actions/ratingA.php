<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}
session_start();

if(isset($_SESSION['logged']) && $_SESSION['logged']){
$name = $_POST['usrname'];
$comment = $_POST['comment'];
$rating = $_POST['rating'];
$prodid = $_POST['prodId'];
$id = $_SESSION['id'];

$sql = "SELECT score, Comments, Name FROM Review WHERE User_idUser = '$id' && Products_idProducts = '$prodid'";
$res = $conn->query($sql)->fetch_assoc();
if(isset($res)){
  $sql = "UPDATE Review SET score = '$rating', Comments = '$comment', Name = '$name' WHERE User_idUser = '$id' && Products_idProducts = '$prodid'";
  $conn->query($sql);
  
  if($prodid == 13){
    header('Location: ../Products/Life.php');
  }
  else if($prodid == 14){
    header('Location: ../Products/Soul.php');
  }
  else if($prodid == 15){
    header('Location: ../Products/Grad.php');
  }
  }
else{
  $sql = "INSERT INTO Review (score, Comments, Name, User_idUser, Products_idProducts)
  VALUES ('$rating', '$comment', '$name', '$id', '$prodid')";
  $conn->query($sql);
  
  if($prodid == 13){
    header('Location: ../Products/Life.php');
  }
  else if($prodid == 14){
    header('Location: ../Products/Soul.php');
  }
  else if($prodid == 15){
    header('Location: ../Products/Grad.php');
  }
  }

}
?>
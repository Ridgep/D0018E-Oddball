<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

session_start();

$amount = intval($_POST['amount']);
$prodprice = intval($_POST['prodprice']);
$total = $prodprice*$amount;
$id = $_SESSION['id'];
$prodid = $_POST['prodId'];
$date = date('Y.m.d');

if(isset($amount) && $amount < 0){
  $_SESSION['Amount'] = 0;
  header('Location: http://utbweb.its.ltu.se/~ridpet-5/Cart.php');
}
else{
  $updated = 0;
  $sql = "SELECT * FROM Orders WHERE User_idUser = '$id' && Products_idProducts = '$prodid'";
  $result = $conn->query($sql);
  while($result1 = $result->fetch_assoc()){
    if(!isset($result1['Ordered'])){
      $amount = $amount + $result1['quant'];
      $total = $amount*$prodprice;
    
      $sql = "UPDATE Orders SET quant = '$amount', Total = '$total', Date = '$date' WHERE User_idUser = '$id' && Products_idProducts = '$prodid'";
      $conn->query($sql);
      $updated = 1;
    }
  }
  if($updated == 0){
    $sql = "INSERT INTO Orders (quant, Total, User_idUser, Products_idProducts, Date)
    VALUES ('$amount', '$total', '$id', '$prodid', '$date')";
    $conn->query($sql);
  }
  header('Location: http://utbweb.its.ltu.se/~ridpet-5/Cart.php');
}

?>
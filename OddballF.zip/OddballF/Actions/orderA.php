<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

session_start();

if(isset($_SESSION['logged']) && $_SESSION['logged']){
  $id = $_SESSION['id'];
  $sql = "SELECT Cost, Stock FROM Products WHERE Prodname = 'Life'";
  $life = $conn->query($sql)->fetch_assoc();
  
  $ltcart = 0;
  $stcart = 0;
  $gtcart = 0;  
  
  $sql = "SELECT * FROM Orders WHERE User_idUser = '$id' && Products_idProducts = '13'";
  $lcart = $conn->query($sql);
  while($Lcart = $lcart->fetch_assoc()){
    if(!isset($Lcart['Ordered'])){
      $ltcart = $Lcart['quant'];
      $loid = $Lcart['idOrders'];
      }
    }
  $ldiff = $life['Stock'] - $ltcart;
  
  $sql = "SELECT Cost, Stock FROM Products WHERE Prodname = 'Soul'";
  $soul = $conn->query($sql)->fetch_assoc();
  
  $sql = "SELECT * FROM Orders WHERE User_idUser = '$id' && Products_idProducts = '14'";
  $scart = $conn->query($sql);
  while($Scart = $scart->fetch_assoc()){
    if(!isset($Scart['Ordered'])){
      $stcart = $Scart['quant'];
      $soid = $Scart['idOrders'];
      }
    }
  $sdiff = $soul['Stock'] - $stcart;
  
  $sql = "SELECT Cost, Stock FROM Products WHERE Prodname = 'Graduation'";
  $grad = $conn->query($sql)->fetch_assoc();
  
  $sql = "SELECT * FROM Orders WHERE User_idUser = '$id' && Products_idProducts = '15'";
  $gcart = $conn->query($sql);
  while($Gcart = $gcart->fetch_assoc()){
    if(!isset($Gcart['Ordered'])){
      $gtcart = $Gcart['quant'];
      $goid = $Gcart['idOrders'];
      }
    }
  $gdiff = $grad['Stock'] - $gtcart;

  
  if($ltcart == 0 && $stcart == 0 && $gtcart == 0){
    header('Location: ../orderF.php');
    }
  elseif(($life['Stock'] > 0 && $ldiff >= 0) && ($soul['Stock'] > 0 && $sdiff >= 0) && ($grad['Stock'] > 0 && $gdiff >= 0)){
    $ordered = 1;
    $date = date('Y.m.d');
    
    $sql = "UPDATE Orders SET Ordered = '$ordered', Date = '$date' WHERE User_idUser = '$id' && Products_idProducts = '13'";
    $conn->query($sql);
    
    $sql = "UPDATE Orders SET Ordered = '$ordered', Date = '$date' WHERE User_idUser = '$id' && Products_idProducts = '14'";
    $conn->query($sql);
   
    $sql = "UPDATE Orders SET Ordered = '$ordered', Date = '$date' WHERE User_idUser = '$id' && Products_idProducts = '15'";
    $conn->query($sql);
    
    $_SESSION['loid'] = $loid;
    $_SESSION['soid'] = $soid;
    $_SESSION['goid'] = $goid;   
    
    $sql = "UPDATE Products SET Stock = '$ldiff' WHERE Prodname = 'Life'";
    $conn->query($sql);
    
    $sql = "UPDATE Products SET Stock = '$sdiff' WHERE Prodname = 'Soul'";
    $conn->query($sql);
    
    $sql = "UPDATE Products SET Stock = '$gdiff' WHERE Prodname = 'Graduation'";
    $conn->query($sql);
    
    header('Location: ../orderS.php');
      
    
   }
    
  else{ header('Location: ../orderF.php');
  }
 }
?>
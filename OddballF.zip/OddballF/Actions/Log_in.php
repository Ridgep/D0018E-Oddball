<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

$uname = $_POST['uname'];
$pass = $_POST['psw'];

$sql = "SELECT Username, Password, idUser, Admin FROM User WHERE Username = '$uname'";

$check = $conn->query($sql)->fetch_assoc();

 


if ($check['Username'] == $uname && $check['Password'] == $pass){
	session_start();
	if(isset($check['Admin']) && $check['Admin']){
	    $_SESSION['admin'] = $check['Admin'];
	}
	$_SESSION['user'] = $check['Username'];
	$_SESSION['id'] = $check['idUser'];
	$id = $_SESSION['id'];
	$_SESSION['logged'] = True;
	
	if(isset($_SESSION['admin']) && $_SESSION['admin']){
	    header('Location: ../admin_page.php');
	}
	else{
	header('Location: ../Cart.php');
	}
}
else{ echo "Password or Username was wrongly entered.";}
?>
<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

session_start();


$_SESSION['Amount'] = intval($_POST['gamount']);

if(isset($_SESSION['Amount']) && $_SESSION['Amount'] < 0){
  $_SESSION['Amount'] = 0;
}

$_SESSION['gCart_quant'] = $_SESSION['gCart_quant'] + $_SESSION['Amount'];

$id = $_SESSION['id'];
$quant = $_SESSION['gCart_quant'];
$gid = $_SESSION['gCart_prodId'];
    
$sql = "UPDATE ShoppingCart SET Quantity = $quant WHERE User_idUser = '$id' && Products_idProducts = '$gid'";
$conn->query($sql);

header('Location: http://utbweb.its.ltu.se/~ridpet-5/Cart.php');
?>
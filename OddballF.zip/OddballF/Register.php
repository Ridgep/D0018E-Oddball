<!DOCTYPE html>
<html>
<?php
$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php include 'Menu.php';?>

<?php

if(isset($_SESSION['logged']) && $_SESSION['logged']){
}
else{
echo "
<form action='Actions/A_register.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <label><b>Email</b></label>
    <input type='text' placeholder='Enter Username' name='uname' required>

    <label><b>Password</b></label>
    <input type='password' placeholder='Enter Password' name='psw' required>
    </p>

    <p>By creating an account you agree to our user agreements.</p>

    <div class='clearfix'>
      <button type='submit' class='signupbtn'>Sign Up</button>
    </div>
  </div>
</form>";
}
include 'Copyright.php';
?>
</body>
</html>
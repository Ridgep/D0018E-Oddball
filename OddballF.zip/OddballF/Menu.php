<?php session_start(); ?>
<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<a href="http://utbweb.its.ltu.se/~ridpet-5/index.php"><h1>Oddball</h1></a>


  <ps>
    <a href="http://utbweb.its.ltu.se/~ridpet-5/Product.php">Product</a>
    <a href="http://utbweb.its.ltu.se/~ridpet-5/Cart.php">Cart</a>
    <?php
    if(isset($_SESSION['logged']) && $_SESSION['logged']){
      if(isset($_SESSION['admin']) && $_SESSION['admin']){
	echo "
	<a href='http://utbweb.its.ltu.se/~ridpet-5/admin_page.php'>Admin Page</a>
	<a href='http://utbweb.its.ltu.se/~ridpet-5/Actions/Log_out.php'>Logout</a>";
	}
      else{
	echo "
	<a href='http://utbweb.its.ltu.se/~ridpet-5/user_page.php'>Logged in as ". $_SESSION['user']."</a>
	<a href='http://utbweb.its.ltu.se/~ridpet-5/Actions/Log_out.php'>Logout</a>";
	}
    }
    else{
    
    echo " 
    <a href='http://utbweb.its.ltu.se/~ridpet-5/Register.php'>Register</a>
    <a href='http://utbweb.its.ltu.se/~ridpet-5/Login.php'>Login</a>";
    }
    ?>
    
    <a href="http://utbweb.its.ltu.se/~ridpet-5/Support.php">Support</a>
  </ps>

</body>
</html>

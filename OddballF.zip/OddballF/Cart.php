<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php include 'Menu.php';

  if(isset($_SESSION['logged']) && $_SESSION['logged']){
  
  $id = $_SESSION['id'];
  $lid = 13;
  $sid = 14;
  $gid = 15;
  
  $sql = "SELECT * FROM Orders WHERE User_idUser = '$id'";
  $orders = $conn->query($sql);
  
  if(!isset($lcart)){
  $lcart = 0;
  }
  
  if(!isset($scart)){
  $scart = 0;
  }
  
  if(!isset($gcart)){
  $gcart = 0;
  }
  
  if(!isset($ltot)){
  $ltot = 0;
  }
  
  if(!isset($stot)){
  $stot = 0;
  }
  
  if(!isset($gtot)){
  $gtot = 0;
  }  
  
  while($cart = $orders->fetch_assoc()){
    if($lid == $cart['Products_idProducts'] && !isset($cart['Ordered'])){
      if(isset($cart['quant'])){
	$lcart = $lcart + $cart['quant'];
	$ltot = $ltot + $cart['Total'];
      }
    }
    elseif($sid == $cart['Products_idProducts'] && !isset($cart['Ordered'])){
      if(isset($cart['quant'])){
	$scart = $scart + $cart['quant'];
	$stot = $stot + $cart['Total'];
      }      
    }
    elseif($gid == $cart['Products_idProducts'] && !isset($cart['Ordered'])){
      if(isset($cart['quant'])){
	$gcart = $gcart + $cart['quant'];
	$gtot = $gtot + $cart['Total'];
	}
      }
    }
  
    echo "Life in your cart " . $lcart . " for a cost of ". $ltot .".<br>
    Souls in your cart " . $scart . " for a cost of ". $stot .".<br>
    Graduations in your cart " . $gcart ." for a cost of ". $gtot .".
    
    <form action='Actions/orderA.php' target='_self' method='POST'>
      <div class='container'>
	<p>
	<button type='submit'>Order</button>
	</p>
    </form>";
  }
  else{ echo "<p><b> You need to be logged in to see your cart! </p></b>"; }

include 'Copyright.php';?>

</body>
</html>
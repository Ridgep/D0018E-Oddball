<!DOCTYPE html>
<html>
<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">

<style>
.table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
.th, .td {
    padding: 15px;
}
</style>
</head>
<body>

<?php include 'Menu.php';

if(isset($_SESSION['logged']) && $_SESSION['logged']){

$sql = "SELECT * FROM Orders WHERE User_idUser = ".$_SESSION['id']."";
$orders = $conn->query($sql);

echo "
<table style='width:35%'>
  <tr>
    <th>Order id</th>
    <th>Product</th>
    <th>Amount</th>
    <th>Total cost</th>
    <th>Order date</th>
  </tr>";
  while($order = $orders->fetch_assoc()){
  if(isset($order['Ordered'])){  
    $sql = "SELECT Prodname FROM Products WHERE idProducts = ".$order['Products_idProducts']."";
    $prodres = $conn->query($sql)->fetch_assoc();
    echo"<tr>
      <td>".$order['idOrders']."</td>
      <td>".$prodres['Prodname']."</td>
      <td>".$order['quant']."</td>
      <td>".$order['Total']."</td>
      <td>".$order['Date']."</td>
    </tr>";
    }
  }
  echo "
</table>";


}

include 'Copyright.php'; ?>

</body>
</html>
<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php include 'Menu.php';?>

<p>Support admin: Ridge Pettersson, ridpet-5@student.ltu.se</p>

<?php include 'Copyright.php';?>
</body>
</html>
<!DOCTYPE html>
<html>
<?php

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">

<style>
.table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
.th, .td {
    padding: 15px;
}
</style>
</head>
<body>

<?php include 'Menu.php';

if(isset($_SESSION['admin']) && $_SESSION['admin']){

$sql = "SELECT Prodname, Description, Cost, Stock FROM Products WHERE Prodname = 'Life'";

$prod = $conn->query($sql)->fetch_assoc();

echo "Product: ".$prod['Prodname']."<br>
Current description: ".$prod['Description']."<br>
Current price: ".$prod['Cost']."<br>

<form action='Actions/editPriceL.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='New price' name='newp' required>
    <button type='submit'>Change</button>
    </p>
</form>

Current stock: ".$prod['Stock']."<br>

<form action='Actions/editStockL.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='Add stock' name='addst' required>
    <button type='submit'>Add</button>
    </p>
</form><br>";

$sql = "SELECT Prodname, Description, Cost, Stock FROM Products WHERE Prodname = 'Soul'";

$prod = $conn->query($sql)->fetch_assoc();

echo "Product: ".$prod['Prodname']."<br>
Current description: ".$prod['Description']."<br>
Current price: ".$prod['Cost']."<br>

<form action='Actions/editPriceS.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='New price' name='newp' required>
    <button type='submit'>Change</button>
    </p>
</form>

Current stock: ".$prod['Stock']."<br>

<form action='Actions/editStockS.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='Add stock' name='addst' required>
    <button type='submit'>Add</button>
    </p>
</form><br>";

$sql = "SELECT Prodname, Description, Cost, Stock FROM Products WHERE Prodname = 'Graduation'";

$prod = $conn->query($sql)->fetch_assoc();

echo "Product: ".$prod['Prodname']."<br>
Current description: ".$prod['Description']."<br>
Current price: ".$prod['Cost']."<br>

<form action='Actions/editPriceG.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='New price' name='newp' required>
    <button type='submit'>Change</button>
    </p>
</form>

Current stock: ".$prod['Stock']."<br>

<form action='Actions/editStockG.php' target='_self' method='POST'>
  <div class='container'>
    <p>
    <input type='text' placeholder='Add stock' name='addst' required>
    <button type='submit'>Add</button>
    </p>
</form><br>";


$sql = "SELECT * FROM Orders";
$orders = $conn->query($sql);

echo "
<table style='width:35%'>
  <tr>
    <th>Order id</th>
    <th>User id</th>
    <th>Name</th>
    <th>Product</th>
    <th>Amount</th>
    <th>Total cost</th>
    <th>Order date</th>
  </tr>";
  while($order = $orders->fetch_assoc()){
  if(isset($order['Ordered'])){
    $sql = "SELECT Username FROM User WHERE idUser = ".$order['User_idUser']."";
    $users = $conn->query($sql)->fetch_assoc();
  
    $sql = "SELECT Prodname FROM Products WHERE idProducts = ".$order['Products_idProducts']."";
    $prodres = $conn->query($sql)->fetch_assoc();
    echo"<tr>
      <td>".$order['idOrders']."</td>
      <td>".$order['User_idUser']."</td>
      <td>".$users['Username']."</td>
      <td>".$prodres['Prodname']."</td>
      <td>".$order['quant']."</td>
      <td>".$order['Total']."</td>
      <td>".$order['Date']."</td>
    </tr>";
    }
  }
  echo "
</table>";


}

include 'Copyright.php'; ?>

</body>
</html>
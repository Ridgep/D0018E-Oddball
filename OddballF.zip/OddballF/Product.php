<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php include 'Menu.php';?>

<p>
  <div class="dropdown">
    <span>Special products</span>
    <div class="dropdown-content">
      <form action="http://utbweb.its.ltu.se/~ridpet-5/Products/Life.php" method="post">
        <input type="submit" value="Life"/>
      </form>
      <form action="http://utbweb.its.ltu.se/~ridpet-5/Products/Soul.php" method="post">
        <input type="submit" value="Soul"/>
      </form>
      <form action="http://utbweb.its.ltu.se/~ridpet-5/Products/Grad.php" method="post">
        <input type="submit" value="Graduation"/>
      </form>
    </div>
  </div>
</p>
<?php

include 'Copyright.php';

?>

</body>
</html>
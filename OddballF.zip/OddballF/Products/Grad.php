<!DOCTYPE html>
<html>
<?php
  require ("../Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="../Stylesheet.css">
<style> 
textarea#cs {
   resize: none;
}
</style>
</head>
</head>
<body>

<?php include '../Menu.php';?>


<p>
  <div class="dropdown">
    <span>Special products</span>
    <div class="dropdown-content">
      <form action="http://utbweb.its.ltu.se/~ridpet-5/Products/Life.php" method="post">
        <input type="submit" value="Life"/>
      </form>
      <form action="http://utbweb.its.ltu.se/~ridpet-5/Products/Soul.php" method="post">
        <input type="submit" value="Soul"/>
      </form>
      <form action="http://utbweb.its.ltu.se/~ridpet-5/Products/Grad.php" method="post">
        <input type="submit" value="Graduation"/>
      </form>
    </div>
  </div>
</p>
<?php
$sql = "SELECT idProducts, Prodname, Description, Cost, Stock FROM Products WHERE Prodname = 'Graduation'";

$prod = $conn->query($sql)->fetch_assoc();
$prodid = $prod['idProducts'];
$_SESSION['gprodid'] = $prod['idProducts'];
$prodprice = $prod['Cost'];

echo "Product: ".$prod['Prodname']."<br>
Description: ".$prod['Description']."<br>
Price: ".$prod['Cost']."<br>
Stock: ".$prod['Stock']."<br>";

if(isset($_SESSION['logged']) && $_SESSION['logged']){
echo "
<form action='../Actions/prod_buy.php' id='purch' target='_self' method='POST'>
  <div class='container'>
    <p>
    <label><b>Amount</b></label>
    <input type='text' placeholder='Enter Amount' name='amount' form='purch' required>
    <button type='submit'>Buy</button>
    <input type = 'hidden' name = 'prodId' form='purch' value = '$prodid'>
    <input type = 'hidden' name = 'prodprice' form='purch' value = '$prodprice'>
    </p>
</form>";

echo "<br><br><p>Leave a comment and rating on how you liked this product!</p><br>
<form action='../Actions/ratingA.php' id='usrform' method='POST'>
  Name: <input type='text' name='usrname'>
  <input type='submit'>
</form>
<br>
<textarea rows='5' cols='50' id='cs' type='text' name='comment' form='usrform' placeholder='Enter text here...'></textarea>

<p>Grading: 
<select name='rating' form='usrform'>
  <option value='1'>1</option>
  <option value='2'>2</option>
  <option value='3'>3</option>
  <option value='4'>4</option>
  <option value='5'>5</option>
</select></p>
<input type = 'hidden' name = 'prodId' form='usrform' value = '$prodid'>";
}
else{
echo "<p><b>Please log in or register to purchase or comment on products!</b></p>";
}

$sql = "SELECT score, Comments, Name FROM Review WHERE Products_idProducts = $prodid";
if($res = $conn->query($sql)){
  while($csection = $res->fetch_assoc()){
    $cname=$csection['Name'];
    $cscore=$csection['score'];
    $ccomment=$csection['Comments'];
    echo "<textarea rows = '1' cols='15' id='cs' type='text' readonly>User: $cname</textarea><br>
    <textarea rows = '1' cols='12' id='cs' type='text' readonly>Rating: $cscore</textarea><br>
    <textarea rows = '5' cols='25' id='cs' type='text' readonly>Said: $ccomment</textarea><br><br>";
    
  }
}

include '../Copyright.php';?>

</body>
</html>
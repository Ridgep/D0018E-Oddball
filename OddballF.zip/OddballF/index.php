<!DOCTYPE html>
<html>
<?php
  require ("Mysqlconnection.php");
?>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php include 'Menu.php';?>

<log> Welcome to Oddball, your online store!</log>

<?php include 'Copyright.php';?>
</body>
</html>
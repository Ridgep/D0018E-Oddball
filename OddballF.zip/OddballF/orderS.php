<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="Stylesheet.css">
</head>
<body>

<?php 

$servername = "utbweb.its.ltu.se:3306";
$username = "ridpet-5";
$password = "ridpet-5";
$db_name = "ridpet5db";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error());
}

include 'Menu.php';

  if(isset($_SESSION['logged']) && $_SESSION['logged']){
  $id = $_SESSION['id'];
  
  $sql = "SELECT quant, Total FROM Orders WHERE idOrders = " . $_SESSION['loid'] . " && User_idUser = '$id'";
  if($res = $conn->query($sql)){
    $life = $res->fetch_assoc();
    echo "Your order for ". $life['quant'] ." Life has been made, your orders id is " . $_SESSION['loid'] . ".<br>
    It will be sent as soon as you pay a total sum of " . $life['Total'] . ".<br><br>";
  }
  
  $sql = "SELECT quant, Total FROM Orders WHERE idOrders = " . $_SESSION['soid'] . " && User_idUser = '$id'";
  if($res = $conn->query($sql)){
    $soul = $res->fetch_assoc();
    echo "Your order for ". $soul['quant'] ." soul(s) has been made, your orders id is " . $_SESSION['soid'] . ".<br>
    It will be sent as soon as you pay a total sum of " . $soul['Total'] . ".<br><br>";
  }
  
  $sql = "SELECT quant, Total FROM Orders WHERE idOrders = " . $_SESSION['goid'] . " && User_idUser = '$id'";
  if($res = $conn->query($sql)){
    $grad = $res->fetch_assoc();
    echo "Your order for ". $grad['quant'] ." graduation(s) has been made, your orders id is " . $_SESSION['goid'] . ".<br>
    It will be sent as soon as you pay a total sum of " . $grad['Total'] . ".<br><br>";
  }
}

include 'Copyright.php';?>

</body>
</html>